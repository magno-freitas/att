package main.java.vet;

public enum ServiceType {
    CONSULTA, BANHO, TOSA, VACINA

}
