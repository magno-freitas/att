package main.java.vet.service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import main.java.vet.model.Pet;
import main.java.vet.util.DatabaseConnection;

public class PetService {
    private static final Logger logger = Logger.getLogger(PetService.class.getName());
    private final AuditService auditService;

    public PetService(AuditService auditService) {
        this.auditService = auditService;
    }

    public void addPet(Pet pet) throws SQLException {
        String query = "INSERT INTO pets (client_id, name, species, breed, birth_date, health_status) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, pet.getClientId());
            stmt.setString(2, pet.getName());
            stmt.setString(3, pet.getSpecies());
            stmt.setString(4, pet.getBreed());
            stmt.setDate(5, pet.getBirthDate());
            stmt.setString(6, pet.getHealthStatus());
            
            stmt.executeUpdate();
            
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    pet.setId(rs.getInt(1));
                }
            }
            
            auditService.logAction("pets", pet.getId(), "INSERT", null, pet.toString());
            logger.info("Pet added successfully with ID: " + pet.getId());
        } catch (SQLException e) {
            logger.severe("Failed to add pet: " + e.getMessage());
            throw e;
        }
    }

    public Pet getPetById(int petId) throws SQLException {
        String query = "SELECT * FROM pets WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, petId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Pet pet = new Pet();
                pet.setId(rs.getInt("id"));
                pet.setClientId(rs.getInt("client_id"));
                pet.setName(rs.getString("name"));
                pet.setSpecies(rs.getString("species"));
                pet.setBreed(rs.getString("breed"));
                pet.setBirthDate(rs.getDate("birth_date"));
                pet.setHealthStatus(rs.getString("health_status"));
                return pet;
            }
            return null;
        } catch (SQLException e) {
            logger.severe("Failed to get pet by ID: " + e.getMessage());
            throw e;
        }
    }

    public List<Pet> getPetsByClient(int clientId) throws SQLException {
        String query = "SELECT * FROM pets WHERE client_id = ? ORDER BY name";
        List<Pet> pets = new ArrayList<>();
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, clientId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Pet pet = new Pet();
                pet.setId(rs.getInt("id"));
                pet.setClientId(rs.getInt("client_id"));
                pet.setName(rs.getString("name"));
                pet.setSpecies(rs.getString("species"));
                pet.setBreed(rs.getString("breed"));
                pet.setBirthDate(rs.getDate("birth_date"));
                pet.setHealthStatus(rs.getString("health_status"));
                pets.add(pet);
            }
            
            logger.info("Retrieved " + pets.size() + " pets for client ID: " + clientId);
            return pets;
        } catch (SQLException e) {
            logger.severe("Failed to get pets by client: " + e.getMessage());
            throw e;
        }
    }

    public void updatePet(Pet pet) throws SQLException {
        String query = "UPDATE pets SET name = ?, species = ?, breed = ?, birth_date = ?, health_status = ? WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, pet.getName());
            stmt.setString(2, pet.getSpecies());
            stmt.setString(3, pet.getBreed());
            stmt.setDate(4, pet.getBirthDate());
            stmt.setString(5, pet.getHealthStatus());
            stmt.setInt(6, pet.getId());
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Pet update failed, no rows affected.");
            }
            
            auditService.logAction("pets", pet.getId(), "UPDATE", null, pet.toString());
            logger.info("Pet updated successfully with ID: " + pet.getId());
        } catch (SQLException e) {
            logger.severe("Failed to update pet: " + e.getMessage());
            throw e;
        }
    }

    public void deletePet(int petId) throws SQLException {
        String query = "DELETE FROM pets WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, petId);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Pet deletion failed, no rows affected.");
            }
            
            auditService.logAction("pets", petId, "DELETE", null, null);
            logger.info("Pet deleted successfully with ID: " + petId);
        } catch (SQLException e) {
            logger.severe("Failed to delete pet: " + e.getMessage());
            throw e;
        }
    }

    public boolean checkVaccinesUpToDate(int petId) throws SQLException {
        String query = "SELECT COUNT(*) FROM vaccine_records WHERE pet_id = ? AND next_dose_date < CURRENT_DATE";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, petId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) == 0;
            }
            return true;
        } catch (SQLException e) {
            logger.severe("Failed to check vaccine status: " + e.getMessage());
            throw e;
        }
    }
}