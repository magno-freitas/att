package main.java.vet.config;

public interface HikariConfigMXBean {

}
