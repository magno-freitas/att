package main.java.vet.config;

public class LoggerFactory {
    // TODO: Implement methods for creating and configuring loggers
    // For example:
    // public static Logger getLogger(String name) { ... }
    // public static void configure(LogConfiguration config) { ... }
}

